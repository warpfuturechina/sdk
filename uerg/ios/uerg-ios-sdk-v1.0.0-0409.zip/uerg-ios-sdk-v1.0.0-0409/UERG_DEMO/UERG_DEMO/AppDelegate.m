//
//  AppDelegate.m
//  UERG_DEMO
//
//  Created by ly on 2018/4/9.
//  Copyright © 2018年 ly. All rights reserved.
//

#import "AppDelegate.h"
#import "UERG.h"

@interface AppDelegate ()<UERGDelegate>

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    [[UERG shareInstance] reloadWithAppId:@"63759c2bade54327a32dc95bcff51472" delegate:self];
    
    return YES;
}


/*!
 * @brief 注册/重载切换场景成功/失败回调
 *
 * @param code 请求响应码（1：成功；其它：失败）
 * @param message 请求响应消息
 */
- (void)didRegisteredFinishing:(NSInteger)code message:(nullable NSString *)message  {
    NSLog(@"code:%ld",code);
    NSLog(@"message:%@",message);
}


/*!
 * @brief 运行过程中出现其它错误回调
 *
 * @param code 错误码
 * @param message 错误信息
 */
- (void)didReceivedError:(NSInteger)code message:(nullable NSString *)message {
    NSLog(@"code:%ld",code);
    NSLog(@"message:%@",message);
}

/*!
 * @brief SDK运行过程中发生状态变更回调
 *
 * @param code SDK状态码
 */
- (void)didReceivedStatusChangeCallback:(NSInteger)code {
    NSLog(@"code:%ld",code);
}
@end
