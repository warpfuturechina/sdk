//
//  UERG.h
//  UERG_SDK_iOS
//
//  Created by ly on 2017/6/1.
//  Copyright © 2017年 lyon. All rights reserved.
//

#define UERG_SDK_VERSION "1.0.0"

#import <Foundation/Foundation.h>

@protocol UERGDelegate;

@interface UERG: NSObject

NS_ASSUME_NONNULL_BEGIN

/*!
 * @brief 初始化UERG单例
 *
 * @return UERG单例
 */
+ (instancetype)shareInstance;

/*!
 * @brief 注册SDK
 *
 * @discussion 向曲速大脑发起注册
 * @param appId 应用ID
 * @param delegate 注册成功或失败接收回调的代理
 */
- (void)registerWithAppId:(NSString *)appId delegate:(id<UERGDelegate>)delegate;

/*!
 * @brief 切换场景
 *
 * @discussion 传入新的appId并重新向曲速大脑注册
 * @param appId 应用ID
 * @param delegate 切换场景成功或失败接收回调的代理对象
 */
- (void)reloadWithAppId:(NSString *)appId delegate:(id<UERGDelegate>)delegate;

NS_ASSUME_NONNULL_END

/*!
 * @brief 获取采集到的环境数据
 *
 * @return 数据包
 */
- (nullable NSString *)getPackage;

/*!
 * @brief 暂停SDK运行
 *
 * @return YES 已暂停
 */
- (BOOL)pause;

/*!
 * @brief 暂停后再次恢复SDK运行
 *
 * @return YES 已恢复
 */
- (BOOL)resume;

/*!
 * @brief 重置场景
 *
 * @discussion 使用上一次注册成功或切换场景成功的环境信息重新运行
 * @return YES 已重置
 */
- (BOOL)reset;

/*!
 * @brief 销毁SDK
 */
- (void)destroy;

@end


@protocol UERGDelegate<NSObject>

@required
/*!
 * @brief 注册/重载切换场景成功/失败回调
 *
 * @param code 请求响应码（1：成功；其它：失败）
 * @param message 请求响应消息
 */
- (void)didRegisteredFinishing:(NSInteger)code message:(nullable NSString *)message;

@optional
/*!
 * @brief 运行过程中出现其它错误回调
 *
 * @param code 错误码
 * @param message 错误信息
 */
- (void)didReceivedError:(NSInteger)code message:(nullable NSString *)message;

/*!
 * @brief SDK运行过程中发生状态变更回调
 *
 * @param code SDK状态码
 */
- (void)didReceivedStatusChangeCallback:(NSInteger)code;

@end
