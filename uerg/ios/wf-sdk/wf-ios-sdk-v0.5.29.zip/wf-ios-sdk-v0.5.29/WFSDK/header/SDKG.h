//
//  SDKG.h
//  WFSDK
//
//  Created by ly on 2017/4/27.
//  Copyright © 2017年 ly. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SDKGDelegate;

@interface SDKG : NSObject

/*!
 * @brief 启动知识图谱
 * @discussion 必须注册成功之后才能启动
 *
 * @param delegate 回调代理
 */
+ (void)start:(id<SDKGDelegate>)delegate;

/*!
 * @brief 获取知识图谱验证码
 *
 * @param delegate 回调代理
 */
+ (void)get:(id<SDKGDelegate>)delegate;

/*!
 * @brief 验证码校验
 * @discussion 对用户操作验证码的结果进行验证（必须进行验证）
 *  若控制台开启了无感验证，且上一次验证通过，曲速大脑识别当前设备为
 *  安全设备，则返回验证通过状态，直接调用check方法并完成相应的登录操作
 *
 * @param delegate 回调代理
 */
+ (void)check:(id<SDKGDelegate>)delegate;

/*!
 * @brief 获取知识图谱验证码（快捷方法）
 * @discussion 合并注册register，启动start，获取get知识图谱方法
 *  合并了WFSDK的 `registerWithAppId:delegate:` 及SDKG的 `start:` 和 `get:` 方法
 *
 * @param appId 应用ID
 * @param delegate 回调代理
 */
+ (void)startup:(NSString *)appId delegate:(id<SDKGDelegate>)delegate;

@end


@protocol SDKGDelegate<NSObject>

@optional

/*!
 * @brief 知识图谱启动回调
 * @discussion SDKG `start:` 的回调方法
 *
 * @param code 回调码
 *  0：失败
 *  1：成功
 * @param message 回调信息
 */
- (void)startCaptchaCallback:(NSInteger)code message:(id)message;

/*!
 * @brief 知识图谱回调
 * @discussion SDKG `get:` 的回调方法
 *
 * @param captchaView 验证码控件，为null获取失败，需要重新获取，获取验证码之后必须重新设置frame
 * @param message 回调信息
 */
- (void)getCaptchaCallback:(UIView *)captchaView message:(id)message;

/*!
 * @brief 知识图谱验证回调
 * @discussion SDKG `check:` 的回调方法
 *  注意：验证完，若还需要验证，不管验证成功或失败，若需要重新获取验证码，注意：点击刷新按钮不起将比起
 *  作用，即需要再次调用`get:`或`startup:delegate:`方法，具体调用哪个方法根据您前面使用哪个方法获
 *  取就再次使用该方法获取一遍验证码。
 *
 * @param token 验证结果返回的token
 * @param message 回调信息
 */
- (void)checkCaptchaCallback:(NSString *)token message:(id)message;

/*!
 * @brief 知识图谱启动回调
 * @discussion SDKG `startup:delegate:` 的回调方法
 *
 * @param captchaView 验证码控件，为null获取失败，需要重新调用startup方法获取，获取验证码之后必
 *  须重新设置frame
 * @param message 回调信息
 */
- (void)startupCaptchaCallback:(UIView *)captchaView message:(id)message;

@end
