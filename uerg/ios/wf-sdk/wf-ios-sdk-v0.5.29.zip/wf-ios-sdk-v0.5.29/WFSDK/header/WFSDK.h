//
//  WFSDK.h
//  WFSDK
//
//  Created by ly on 2017/4/11.
//  Copyright © 2017年 ly. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol WFSDKDelegate;

typedef NS_ENUM(NSUInteger, WFSDKProductType) {
    WFSDKProductTypeAll   = 0,  // 所有产品
    WFSDKProductTypeUERG  = 1,  // 人机识别
    WFSDKProductTypeDVID  = 2,  // 设备指纹
    WFSDKProductTypeSDKG  = 3   // 知识图谱
};

@interface WFSDK : NSObject

/*!
 * @brief 注册WFSDK
 * @discussion SDK向曲速大脑注册，标记为SDK生命周期的开始
 *  所有产品的使用均依赖于SDK注册成功的状态（提供快捷接入方式的产品除外）
 *
 * @param appId 应用ID
 * @param delegate 回调代理
 */
+ (void)registerWithAppId:(NSString *)appId delegate:(id<WFSDKDelegate>)delegate;

/*!
 * @brief 启动指定产品
 * @discussion SDK注册成功后，只是启动了SDK，并未启动任何一款产品或你所需要的功能
 *  想要获得某种保护的能力，需要通过该接口指定需要开启的产品或功能（也可以使用产品里面提
 *  供的`start:`方法来替代此通用方法）
 *  只有当 productType 取值为 WFSDKProductTypeAll 时，启动成功或失败的会调用
 *  WFSDKDelegate 的 `startCallback:message:` 代理方法作为标记。productType
 *  为其它取值情况时都是执行产品内部所指定的`start:`回调方法。
 *
 * @param productType 产品类型
 * @param delegate 回调代理
 */
+ (void)start:(WFSDKProductType)productType delegate:(id)delegate;

/*!
 * @brief 暂停SDK
 * @discussion 调用该方法SDK将暂停所有已经开启的产品（停止保护），可通过`resume:`方
 *  法再次开启
 *
 * @param delegate 回调代理
 */
+ (void)pause:(id<WFSDKDelegate>)delegate;

/*!
 * @brief 恢复SDK
 * @discussion 调用该方法SDK将恢复之前已经开启但已被暂停(`pause:`)的所有产品。
 *
 * @param delegate 回调代理
 */
+ (void)resume:(id<WFSDKDelegate>)delegate;

/*!
 * @brief 重启SDK
 * @discussion 调用该方法SDK将停止已经启动的产品，并恢复注册成功时的状态。并需要
 *  根据您的需求，重新开启指定的产品
 *
 * @param delegate 回调代理
 */
+ (void)reset:(id<WFSDKDelegate>)delegate;

/*!
 * @brief 销毁SDK
 * @discussion 调用该方法SDK将停止工作及销毁所有的状态。当不再需要SDK提供任何保护
 *  时调用该方法。
 *
 * @param delegate 回调代理
 */
+ (void)destory:(id<WFSDKDelegate>)delegate;

@end


@protocol WFSDKDelegate<NSObject>

@optional

/*!
 * @brief SDK消息回调
 * @discussion WFSDK `registerWithAppId:delegate:` 的回调方法
 *
 * @param code 回调码
 *  0：失败
 *  1：成功
 * @param message 回调信息
 */
- (void)registerCallback:(NSInteger)code message:(id)message;

/*!
 * @brief 启动回调
 * @discussion WFSDK `start:delegate:` 的回调方法
 *  WFSDKProductType=WFSDKProductTypeAll回调启动成功与否
 *
 * @param code 回调码
 *  0：失败
 *  1：成功
 * @param message 回调信息
 */
- (void)startCallback:(NSInteger)code message:(id)message;

/*!
 * @brief 暂停回调
 * @discussion WFSDK `pause:` 的回调方法
 *
 * @param code 回调码
 *  0：失败
 *  1：成功
 * @param message 回调信息
 */
- (void)pauseCallback:(NSInteger)code message:(id)message;

/*!
 * @brief 恢复回调
 * @discussion WFSDK `resume:` 的回调方法
 *
 * @param code 回调码
 *  0：失败
 *  1：成功
 * @param message 回调信息
 */
- (void)resumeCallback:(NSInteger)code message:(id)message;

/*!
 * @brief 重启回调
 * @discussion WFSDK `reset:` 的回调方法
 *
 * @param code 回调码
 *  0：失败
 *  1：成功
 * @param message 回调信息
 */
- (void)resetCallback:(NSInteger)code message:(id)message;

/*!
 * @brief 销毁回调
 * @discussion  WFSDK `destory:` 的回调方法
 *
 * @param code 回调码
 *  0：失败
 *  1：成功
 * @param message 回调信息
 */
- (void)destoryCallback:(NSInteger)code message:(id)message;

@end
