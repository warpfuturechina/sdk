//
//  UERG.h
//  WFSDK
//
//  Created by ly on 2017/4/27.
//  Copyright © 2017年 ly. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol UERGDelegate;

@interface UERG : NSObject

/*!
 * @brief 启动UERG
 * @discussion 在启动UERG之前，必须等SDK注册成功之后才能启动
 *  UERG的运行状态同SDK的生命周期保持一致，需要控制UERG的运行状态的话，通过WFSDK来实现
 *
 * @param delegate 回调代理
 */
+ (void)start:(id<UERGDelegate>)delegate;

/*!
 * @brief 获取数据包
 * @discussion SDK注册完及启动UERG之后才能调用。在需要进行风险识别时，调用该方法获取到
 *  上下文运行环境的数据包，并将获取到的数据包提交给您的服务器，由服务器调用验证接口进行风险
 *  识别和验证。如：在注册登录或是抢红包等应用场景，在开始注册登录或是抢红包前，您可以使用UERG
 *  风险识别产品，并调用该方法拿到环境相关的数据包，将数据包发送给您的服务器，服务器验证完成
 *  之后返回自定义的指令是否允许该用户进行注册登录或是抢红包的操作。
 *
 * @return 数据包
 */
+ (NSString *)getPackage;

@end


@protocol UERGDelegate<NSObject>

@optional

/*!
 * @brief UERG启动回调
 * @discussion UERG `start:` 的回调方法
 *
 * @param code 回调码
 *  0：失败
 *  1：成功
 * @param message 回调信息
 */
- (void)startUERGCallback:(NSInteger)code message:(id)message;

@end

