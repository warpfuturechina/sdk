//
//  KLCA.h
//  WFSDK
//
//  Created by ly on 2018/4/27.
//  Copyright © 2018年 ly. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol KLCADelegate;

@interface KLCA : NSObject

/*!
 * @brief 获取知识图谱验证码
 * @param delegate 回调代理
 */
+ (void)get:(id<KLCADelegate>)delegate;

/*!
 * @brief 验证码校验
 * @discussion check校验完成之后，如果需要再次进行check，成功与否都应当先调用get重新 获取验证码 
 *
 * @param delegate 回调代理
 */
+ (void)check:(id<KLCADelegate>)delegate;

/*!
 * @brief 获取知识图谱验证码（快捷方法）
 * @discussion 合并注册register，启动start，获取get知识图谱方法
 *
 * @param appId 应用ID
 * @param delegate 回调代理
 */
+ (void)startup:(NSString *)appId delegate:(id<KLCADelegate>)delegate;

@end


@protocol KLCADelegate<NSObject>

/*!
 * @brief 知识图谱启动回调
 * @discussion 获取验证码或校验验证码时内部启动相关模块并回调
 *
 * @param code 回调码
 *  0：失败
 *  1：成功
 * @param message 回调信息
 */
- (void)startCaptchaCallback:(NSInteger)code message:(id)message;

/*!
 * @brief 知识图谱回调
 * @discussion 获取验证码控件，get的回调方法
 *
 * @param captchaView 验证码控件，为null获取失败，需要重新获取
 * @param message 回调信息
 */
- (void)getCaptchaCallback:(UIView *)captchaView message:(id)message;

/*!
 * @brief 知识图谱验证回调
 * @discussion 提交结果并验证码结果，check的回调方法
 *
 * @param token 验证结果token
 * @param message 回调信息
 */
- (void)checkCaptchaCallback:(NSString *)token message:(id)message;

/*!
 * @brief 知识图谱启动回调
 * @discussion 合并注册register，启动start，获取get知识图谱方法的回调，startup的回调方法
 *
 * @param captchaView 验证码控件，为null获取失败，需要重新获取
 * @param message 回调信息
 */
- (void)startupCaptchaCallback:(UIView *)captchaView message:(id)message;

@end
