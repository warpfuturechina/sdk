//
//  UERG.h
//  WFSDK
//
//  Created by ly on 2018/4/27.
//  Copyright © 2018年 ly. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol UERGDelegate;

@interface UERG : NSObject

/*!
 * @brief 获取数据包
 * @discussion 注册完之后调用
 *
 * @return 数据包字符串
 */
+ (NSString *)getPackage;

@end

@protocol UERGDelegate<NSObject>

/*!
 * @brief UERG启动回调
 * @discussion 启动并执行UERG，回调启动状态
 *
 * @param code 回调码
 *  0：失败
 *  1：成功
 * @param message 回调信息
 */
- (void)startUERGCallback:(NSInteger)code message:(id)message;

@end

