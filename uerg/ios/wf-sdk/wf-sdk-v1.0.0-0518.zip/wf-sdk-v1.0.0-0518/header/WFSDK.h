//
//  WFSDK.h
//  WFSDK
//
//  Created by ly on 2018/4/11.
//  Copyright © 2018年 ly. All rights reserved.
//

#import <Foundation/Foundation.h>

#define WFSDK_VERSION "1.0.0"

@protocol WFSDKDelegate;

typedef NS_ENUM(NSUInteger, WFSDKProductType) {
    WFSDKProductTypeAll   = 0,  // 所有产品
    WFSDKProductTypeUERG  = 1,  // 人机识别
    WFSDKProductTypeDVID  = 2,  // 设备指纹
    WFSDKProductTypeKLCA  = 3,  // 知识图谱
    WFSDKProductTypeRadar = 4,  // 终端雷达
};

@interface WFSDK : NSObject

/*!
 * @brief 注册SDK
 * @discussion SDK向曲速大脑注册
 *
 * @param appId 应用ID
 * @param delegate 回调代理
 */
+ (void)registerWithAppId:(NSString *)appId delegate:(id<WFSDKDelegate>)delegate;

/*!
 * @brief 启动指定产品
 * @discussion 注册成功后，启动指定的产品
 *
 * @param productType 产品类型
 * @param delegate 回调代理
 */
+ (void)start:(WFSDKProductType)productType delegate:(id<WFSDKDelegate>)delegate;

/*!
 * @brief 暂停SDK
 * @discussion SDK将暂停所有产品的运行
 *
 * @param delegate 回调代理
 */
+ (void)pause:(id<WFSDKDelegate>)delegate;

/*!
 * @brief 恢复SDK
 * @discussion SDK将恢复所有产品的运行
 *
 * @param delegate 回调代理
 */
+ (void)resume:(id<WFSDKDelegate>)delegate;

/*!
 * @brief 重启SDK
 * @discussion SDK将重启
 *
 * @param delegate 回调代理
 */
+ (void)reset:(id<WFSDKDelegate>)delegate;

/*!
 * @brief 销毁SDK
 * @discussion SDK将停止工作及销毁
 *
 * @param delegate 回调代理
 */
+ (void)destory:(id<WFSDKDelegate>)delegate;

@end


@protocol WFSDKDelegate<NSObject>

@required

/*!
 * @brief SDK消息回调
 * @discussion SDK注册回调或是中间运行状态回调
 *
 * @param code 回调码
 *  0：失败
 *  1：成功
 * @param message 回调信息
 */
- (void)registerCallback:(NSInteger)code message:(id)message;

@optional

/*!
 * @brief 启动回调
 * @discussion WFSDKProductType=WFSDKProductTypeAll回调启动成功与否
 *
 * @param code 回调码
 *  0：失败
 *  1：成功
 * @param message 回调信息
 */
- (void)startCallback:(NSInteger)code message:(id)message;

/*!
 * @brief 暂停回调
 * @discussion 暂停SDK工作
 *
 * @param code 回调码
 *  0：失败
 *  1：成功
 * @param message 回调信息
 */
- (void)pauseCallback:(NSInteger)code message:(id)message;

/*!
 * @brief 恢复回调
 * @discussion 恢复SDK工作
 *
 * @param code 回调码
 *  0：失败
 *  1：成功
 * @param message 回调信息
 */
- (void)resumeCallback:(NSInteger)code message:(id)message;

/*!
 * @brief 重启回调
 * @discussion SDK将重新开始运行
 *
 * @param code 回调码
 *  0：失败
 *  1：成功
 * @param message 回调信息
 */
- (void)resetCallback:(NSInteger)code message:(id)message;

/*!
 * @brief 销毁回调
 * @discussion SDK销毁回调
 *
 * @param code 回调码
 *  0：失败
 *  1：成功
 * @param message 回调信息
 */
- (void)destoryCallback:(NSInteger)code message:(id)message;

@end
