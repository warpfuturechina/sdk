//
//  DVID.h
//  WFSDK
//
//  Created by ly on 2018/4/27.
//  Copyright © 2018年 ly. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol DVIDDelegate;

@interface DVID : NSObject

/*!
 * @brief 获取设备指纹
 * @discussion 注册之后调用，获取设备指纹
 *
 * @param delegate 回调代理
 */
+ (void)get:(id<DVIDDelegate>)delegate;

/*!
 * @brief 验证设备指纹
 * @discussion 校验指纹
 *
 * @param delegate 回调代理
 * @param extra 拓展信息
 */
+ (void)check:(id<DVIDDelegate>)delegate extra:(nullable id)extra;

@end

@protocol DVIDDelegate<NSObject>

/*!
 * @brief 设备指纹启动回调
 * @discussion 获取设备指纹或校验设备指纹时会先启动相关模块
 *
 * @param code 回调码
 *  0：失败
 *  1：成功
 * @param message 回调信息
 */
- (void)startDeviceIdCallback:(NSInteger)code message:(id)message;

/*!
 * @brief 设备指纹回调
 * @discussion 获取设备指纹回调
 *
 * @param deviceId 设备指纹
 * @param message 回调信息
 */
- (void)getDeviceIdCallback:(NSString *)deviceId message:(id)message;

/*!
 * @brief 验证设备指纹回调
 * @discussion 验证指纹风险结果回调
 *
 * @param data 校验结果
 * risk: 0,没有风险; 1,有风险
 * grade: 风险等级, 1~10, 越大风险越高
 * @param message 回调信息
 */
- (void)checkDeviceIdCallback:(id)data message:(id)message;

@end


