//
//  UERG.h
//  WFSDK
//
//  Created by ly on 2017/4/27.
//  Copyright © 2017年 ly. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol UERGDelegate;

@interface UERG : NSObject

/*!
 * @brief 启动UERG
 * @discussion 必须在注册之后才能启动
 *  UERG的运行状态同SDK的生命周期保持一致，需要控制UERG的运行状态的话，通过WFSDK来实现
 *
 * @param delegate 回调代理
 */
- (void)start:(id<UERGDelegate>)delegate;

/*!
 * @brief 获取数据包
 * @discussion SDK注册完及启动UERG之后才能调用
 *
 * @return UERG数据包
 */
+ (NSString *)getPackage;

@end


@protocol UERGDelegate<NSObject>

@optional

/*!
 * @brief UERG启动回调
 * @discussion 启动并执行UERG，回调启动状态
 *
 * @param code 回调码
 *  0：失败
 *  1：成功
 * @param message 回调信息
 */
- (void)startUERGCallback:(NSInteger)code message:(id)message;

@end

