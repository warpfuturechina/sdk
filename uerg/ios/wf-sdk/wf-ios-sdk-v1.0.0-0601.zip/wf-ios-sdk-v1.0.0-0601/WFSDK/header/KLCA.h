//
//  KLCA.h
//  WFSDK
//
//  Created by ly on 2017/4/27.
//  Copyright © 2017年 ly. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol KLCADelegate;

@interface KLCA : NSObject

/*!
 * @brief 启动知识图谱
 * @discussion 必须注册成功之后才能启动
 *
 * @param delegate 回调代理
 */
- (void)start:(id<KLCADelegate>)delegate;

/*!
 * @brief 获取知识图谱验证码
 *
 * @param delegate 回调代理
 */
+ (void)get:(id<KLCADelegate>)delegate;

/*!
 * @brief 验证码校验
 * @discussion 对用户操作验证码的结果进行验证（必须进行验证）
 *  若控制台开启了无感验证，且上一次验证通过，曲速大脑识别当前设备为
 *  安全设备，则返回验证通过状态，直接调用check方法并完成相应的登录操作
 *
 * @param delegate 回调代理
 */
+ (void)check:(id<KLCADelegate>)delegate;

/*!
 * @brief 获取知识图谱验证码（快捷方法）
 * @discussion 合并注册register，启动start，获取get知识图谱方法
 *
 * @param appId 应用ID
 * @param delegate 回调代理
 */
+ (void)startup:(NSString *)appId delegate:(id<KLCADelegate>)delegate;

@end


@protocol KLCADelegate<NSObject>

@optional

/*!
 * @brief 知识图谱启动回调
 * @discussion 获取验证码或校验验证码时内部启动相关模块并回调
 *
 * @param code 回调码
 *  0：失败
 *  1：成功
 * @param message 回调信息
 */
- (void)startCaptchaCallback:(NSInteger)code message:(id)message;

/*!
 * @brief 知识图谱回调
 * @discussion 获取验证码控件，get的回调方法
 *
 * @param captchaView 验证码控件，为null获取失败，需要重新获取，获取验证码之后必须重新设置frame
 * @param message 回调信息
 */
- (void)getCaptchaCallback:(UIView *)captchaView message:(id)message;

/*!
 * @brief 知识图谱验证回调
 * @discussion 提交结果并验证码结果，check的回调方法
 *
 * @param token 验证结果返回的token
 * @param message 回调信息
 */
- (void)checkCaptchaCallback:(NSString *)token message:(id)message;

/*!
 * @brief 知识图谱启动回调
 * @discussion 合并注册register，启动start，获取get知识图谱方法的回调，startup的回调方法
 *
 * @param captchaView 验证码控件，为null获取失败，需要重新调用startup方法获取，获取验证码之后必须重新设置frame
 * @param message 回调信息
 */
- (void)startupCaptchaCallback:(UIView *)captchaView message:(id)message;

@end
